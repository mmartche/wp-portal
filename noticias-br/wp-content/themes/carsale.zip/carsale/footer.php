
		</div><!-- #main -->
<hr />
<div class="modal fade" id="comunicar-erro" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="myModalLabel"> - </h4>
      </div>
      <div class="modal-body">
        <form>
        	<p>?</p>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div>
		<footer id="colophon" class="site-footer" role="contentinfo">
			<?php /* get_sidebar( 'footer' ); */ ?>

			<div class="site-info">
				<?php do_action( 'carsale_credits' ); ?>
				<a href="<?php echo esc_url( __( 'http://carsale.com.br/', 'carsale' ) ); ?>"></a>
			</div><!-- .site-info -->
		</footer><!-- #colophon -->
	</div><!-- #page -->

	<?php wp_footer(); ?>

	<footer>
        <div class="footerTitle">Central de Atendimento Carsale - (11) 3274 5900</div>
        <nav class="footerItemsTop">
            <a title="O que é o Carsale" href="http://carsale.uol.com.br/novosite/institucional/oCarsale.asp">O que é o Carsale</a>
            <a title="Publicidade" href="http://carsale.uol.com.br/novosite/institucional/publicidade.asp">Publicidade</a>
            <a title="Expediente" href="http://carsale.uol.com.br/novosite/institucional/expediente.asp">Expediente</a>
            <a title="Fale conosco" href="http://carsale.uol.com.br/novosite/institucional/faleConosco.asp">Fale conosco</a>
        </nav>
        <nav class="footerMenu">
            <ul>
                <li class="footerMenuTitle">Classificados</li>
                <li><a title="Explorador" href="http://carsale.uol.com.br/classificado/explorador">Explorador</a></li>
                <li><a title="Mega Ofertas" href="http://carsale.uol.com.br/classificado/mega-oferta">Mega Ofertas</a></li>
            </ul>
            <ul>
                <li class="footerMenuTitle">Notícias</li>
                <li><a title="Carsale | notícias Automotivas | Notícias" href="http://noticias.carsale.uol.com.br">Últimas</a></li>
                <li><a title="Carsale | notícias Automotivas | Testes" href="http://noticias.carsale.uol.com.br">Testes</a></li>
                <li><a title="Carsale | notícias Automotivas | Lançamentos" href="http://noticias.carsale.uol.com.br">Lançamentos</a></li>
                <li><a title="Carsale | notícias Automotivas | Vídeos" href="http://noticias.carsale.uol.com.br">Vídeos</a></li>
                <li><a title="Carsale | notícias Automotivas | Classificados" href="http://noticias.carsale.uol.com.br">Classificados</a></li>
                <li><a title="Carsale | notícias Automotivas | Segredos" href="http://noticias.carsale.uol.com.br">Segredos</a></li>
                <li><a title="Carsale | notícias Automotivas | Carros Verdes" href="http://noticias.carsale.uol.com.br">Carros Verdes</a></li>
                <li><a title="Carsale | notícias Automotivas | Alta Rodagem" href="http://noticias.carsale.uol.com.br">Alta Rodagem</a></li>
                <li><a title="Carsale | notícias Automotivas | Blog" href="http://noticias.carsale.uol.com.br">Blog</a></li>
            </ul>
            <!-- <ul>
                <li class="footerMenuTitle">Interativo</li>
                <li><a title="Carsale - Enquete" href="/novosite/interativo/enquete/">Enquete</a></li>
                <li><a title="Carsale - Fórum" href="/novosite/interativo/forum/">Fórum</a></li>
                <li><a title="Carsale - Opinião do dono" href="/novosite/interativo/opdono/">Opinião do Dono</a></li>
                <li><a title="Carsale - Papel de parede" href="/Novosite/interativo/wallpaper/">Papel de parede</a></li>
            </ul> -->
            <!-- <ul>
                <li class="footerMenuTitle">Multimídia</li>
                <li><a title="Carsale - Enquete" href="/novosite/hotsite/fotos/listagem.asp">Galerias de fotos</a></li>
                <li><a title="Carsale - Vídeos" href="/novosite/hotsite/video/listagem.asp">Vídeos</a></li>
                <li><a title="" href="#">Saiba Mais</a></li>
            </ul> -->
            <ul>
                <li class="footerMenuTitle">Guia do Motorista</li>
                <li><a title="Carsale - Explorador" href="http://carsale.uol.com.br/compracoletiva/">Compra Coletiva</a></li>
                <li><a title="Opinião do Dono" href="http://carsale.uol.com.br/novosite/interativo/opdono/">Opinião do Dono</a></li>
                <li><a title="Carsale Corretora" href="http://www.carsalecorretora.com.br/" target="_blank">Carsale Corretora</a></li>
                <!-- <li><a title="Dicas e Serviços" href="http://carsale.uol.com.br/editorial/dicas-e-servicos/listagem" target="_blank">Dicas e Serviços</a></li> -->
                <!-- <li><a title="Carsale - Calendários" href="/novosite/revista/calendario/calendario.asp">Calendários</a></li> -->
                <!-- <li><a title="Carsale - Licenciamento" href="/novosite/servicos/licenciamento/">Licenciamento</a></li> -->
                <!-- <li><a title="Carsale - Recall" href="http://carsale.uol.com.br/Novosite/servicos/recall/">Recall</a></li> -->
            </ul>
        </nav>
        <!-- <div class="footerLogoBlog">
            <a target="_blank" href="http://noticias.carsale.uol.com.br/blog" class="footerBlogImg" title=""></a>
        </div>
        <div class="footerLogoCompra">
            <a target="_blank" href="http://carsale.uol.com.br/compracoletiva/index.asp" class="footerCompraImg" title=""></a>
        </div> -->
        <div class="copyright">Av do Estado, 5200, CEP: 01516-000, São Paulo - SP   ---     Copyright 2000-2013 Carsale.com.br - Todos os direitos reservados</div>
    </footer>

 <!-- SiteCatalyst code version: H.20.2. Copyright 1997-2009 Omniture, Inc. More info available athttp://www.omniture.com -->
<script language="JavaScript" type="text/javascript" src="http://me.jsuol.com/omtr/carsale.js"></script>
<script language="JavaScript" type="text/javascript"><!--
/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
var s_code=uol_sc.t();if(s_code)document.write(s_code)//--></script>
<!-- End SiteCatalyst code version: H.20.2. -->  

<?php
/*
<script type="text/javascript">
var uolJsHost = (("https:" == document.location.protocol) ? "https://ssl.carsale.com.br/js/carsale.js" : "http://me.jsuol.com/omtr/carsale.js");
document.write(unescape("%3Cscript language='JavaScript' src='" + uolJsHost + "' type='text/javascript' %3E%3C/script%3E"));
</script>
<script type="text/javascript"><!--
uol_sc.channel="Carros-parceiros-carsale";
/ ************* DO NOT ALTER ANYTHING BELOW THIS LINE ! ************** /
var s_code=uol_sc.t();if(s_code)document.write(s_code)//--></script>
<!-- End SiteCatalyst code version: H.20.2. -->
*/
?>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-10478324-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
 </script>

 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-10478324-4', 'carsale.uol.com.br');
  ga('send', 'pageview');

</script>
</body>
</html>
